import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;


public class P159Tester {
	public static Scanner in = null;
	public static TreeMap<String, String> map = new TreeMap<String, String>();
	public static String name;
	public static String grade;

	public static void main(String[] args) {
		boolean i = true;
		while(i ){
			in = new Scanner(System.in);
			System.out.print("Please enter: A for Add, R for remove, M for modify, P for print,Q for quiet");
			String choice = in.next();
			if(choice.equals("A")||choice.equals("a")) add();
			if(choice.equals("R")||choice.equals("R")) remove();
			if(choice.equals("M")||choice.equals("m")) modify();
			if(choice.equals("P")||choice.equals("p")) print();
			if(choice.equals("Q")||choice.equals("q")) i=false;
		}
	}
	private static void print() {
		for (Entry<String, String> entry : map.entrySet()) {
		    String key = entry.getKey();
		    String value = entry.getValue();

		    System.out.printf("%s: %s\n", key, value);
		}
	}
	private static void modify() {
		System.out.print("Enter the name of student and the grade:");
		name = in.next();
		grade = in.next();
		map.remove(name);
		map.put(name,grade);
	}
	private static void remove() {
		System.out.print("Enter the name of student:");
		name = in.next();
		map.remove(name);
	}
	public static void add(){
		System.out.print("Enter the name of student and the grade:");
		name = in.next();
		grade = in.next();
		map.put(name, grade);
	}
	
	
}
