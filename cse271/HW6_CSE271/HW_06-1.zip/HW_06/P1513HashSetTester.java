import java.io.File;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

//Base on average result the hashSet always faster than TreeSet.

public class P1513HashSetTester {
	public static Scanner fin = null;
	public static String line;
	public static Set<String> hs = new HashSet<String>();
	public static Set<String> ts = new TreeSet<String>();
	public static long start,end;
	
	public static void main(String[] args) {

		HashSetFill();
		TreeSetFill();
		
	}
	private static void HashSetFill(){
		try {
			fin = new Scanner(new File("war-and-peace.txt"));
			start = System.currentTimeMillis();
			while(fin.hasNext()){
				line = fin.next();
				hs.add(line);
			}
			end = System.currentTimeMillis();
			System.out.println("Time for insert all the text into Hashset: "+(end-start));
			System.gc();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if(fin != null) fin.close();
		}
	}
	private static void TreeSetFill(){
		try {
			fin = new Scanner(new File("war-and-peace.txt"));
			start = System.currentTimeMillis();
			while(fin.hasNext()){
				line = fin.next();
				ts.add(line);
			}
			end = System.currentTimeMillis();
			System.out.println("Time for insert all the text into Treeset: "+(end-start));
			System.gc();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if(fin != null) fin.close();
		}
	}
}
