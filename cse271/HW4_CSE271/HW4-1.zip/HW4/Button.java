import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

//P10.1
public class Button extends JPanel {
	public Button() {
		JFrame frame = new JFrame();
		
		JPanel panel = new JPanel();
		for (int i = 1; i < 101; i++) {
			JButton button = new JButton("" + i);
			panel.add(button);
		}
		frame.add(panel);
		frame.setTitle("100 Butons");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500,500);
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		JPanel testFrame = new Button();
	}
}
