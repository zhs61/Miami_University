import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

// P 10.26
public class OlypicRing extends JPanel{

	JFrame window = new JFrame("Olympic Ring");

	public OlypicRing(){
		window.setBounds(100, 100, 500, 500);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.getContentPane().add(this);
		window.setVisible(true);
		window.setBackground(Color.WHITE);

	}

	@Override
	protected void paintComponent(Graphics g) {
		//Blue
		for(int i =0 ; i<10;i++){
		g.setColor(Color.BLUE);
		g.drawOval(100+i,100+i,100-2*i,100-2*i);
		}

		
		//Black
		
		for(int i =0 ; i<10;i++){
			g.setColor(Color.BLACK);
			g.drawOval(200+i,100+i,100-2*i,100-2*i);
			}
		
		//Red
		for(int i =0 ; i<10;i++){
			g.setColor(Color.RED);
			g.drawOval(300+i,100+i,100-2*i,100-2*i);
			}
		
		//Yellow
		for(int i =0 ; i<10;i++){
			g.setColor(Color.YELLOW);
			g.drawOval(150+i,150+i,100-2*i,100-2*i);
			}
		//Green
		for(int i =0 ; i<10;i++){
			g.setColor(Color.GREEN);
			g.drawOval(250+i,150+i,100-2*i,100-2*i);
			}
	}
	
	public void drawRing(int x,int y, Color color){
		Graphics g = null;
		for(int i =0 ; i<10;i++){
			g.setColor(color);
			g.drawOval(x+i,y+i,100-2*i,100-2*i);
			}
		
	}

	public static void main(String[] args) {
		new OlypicRing();
		

	}

}
